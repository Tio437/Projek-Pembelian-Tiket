package com.projekpbo.pemesanan_tiket_bioskop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PemesananTiketBioskopApplication {

	public static void main(String[] args) {
		SpringApplication.run(PemesananTiketBioskopApplication.class, args);
	}

}
